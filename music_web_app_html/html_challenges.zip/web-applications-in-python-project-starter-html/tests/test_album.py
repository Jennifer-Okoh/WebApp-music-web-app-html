from lib.album import Album

"""
Artist constructs with an id, title, release_year, artist_id
"""
def test_album_constructs():
    album = Album(1, "Test title", "Test release_year", "Test artist_id")
    assert album.id == 1
    assert album.title == "Test title"
    assert album.release_year == "Test release_year"
    assert album.artist_id == "Test artist_id"

"""
We can compare two identical albums
And have them be equal
"""
def test_artists_are_equal():
    album1 = Album(1, "Test title", "Test release_year", "Test artist_id")
    album2 = Album(1, "Test title", "Test release_year", "Test artist_id")
    assert album1 == album2

"""
We can format album to strings nicely
"""
def test_album_format_nicely():
    album = Album(1, "Test title", "Test release_year", "Test artist_id")
    assert str(album) == "Album(1, Test title, Test release_year, Test artist_id)"