from playwright.sync_api import Page, expect

# Tests for your routes go here

# === Example Code Below ===

"""
We can get an emoji from the /emoji page
"""
def test_get_emoji(page, test_web_address): # Note new parameters
    # We load a virtual browser and navigate to the /emoji page
    page.goto(f"http://{test_web_address}/emoji")

    # We look at the <strong> tag
    strong_tag = page.locator("strong")

    # We assert that it has the text ":)"
    expect(strong_tag).to_have_text(":)")

# get albums
def test_get_albums(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/albums")
    div_tags = page.locator("div")
    expect(div_tags).to_have_text([
        "Title: Doolittle\nReleased: 1989",
        "Title: Surfer Rosa\nReleased: 1988"
    ])
# get first album
def get_first_album(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/Doolittle")
    h1_tags = page.locator("h1")
    expect(h1_tags).to_have_text(["Doolittle"])
    paragraph_tags = page.locator("p")
    expect(paragraph_tags).to_have_text([
        "Release_year: 1989\nArtist: Pixies"
    ])
# get 2nd album
def get_second_album(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/Surfer Rosa")
    h1_tags = page.locator("h1")
    expect(h1_tags).to_have_text(["Surfer Rosa"])
    paragraph_tags = page.locator("p")
    expect(paragraph_tags).to_have_text([
        "Release_year: 1988\nArtist: Pixies"
    ])


# ==============
# Exercise
# Test-drive and implement the following change:

# The page returned by GET /albums should contain a link for each album listed. It should link to /albums/<id>, where <id> is the corresponding album's id. That page should then show information about the specific album.

# Run the server and make sure you can navigate, using your browser, from the albums list page to the single album page.

def test_get_single_album_page(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/albums")
    page.click("text='Title: Surfer Rosa'")
    h1_tags = page.locator("h1")
    expect(h1_tags).to_have_text("Album: Surfer Rosa")

# ==============
# Challenge
# Test-drive and implement the following changes to the music_web_app_html project:

# Add a route GET /artists/<id> which returns an HTML page showing details for a single artist.
# Add a route GET /artists which returns an HTML page with the list of artists. This page should contain a link for each artist listed, linking to /artists/<id> where <id> needs to be the corresponding artist id.

def test_single_artist_page(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/artists")
    page.click("text='Name: Pixies'")
    div_tags = page.locator("div")
    expect(div_tags).to_have_text("Artist: Pixies\nGenre: Rock")


def test_list_of_artists(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/artists")
    div_tags = page.locator("div")
    expect(div_tags).to_have_text([
        "Name: Pixies\nGenre: Rock",
        "Name: ABBA\nGenre: Pop",
        "Name: Taylor Swift\nGenre: Pop",
        "Name: Nina Simone\nGenre: Jazz"
    ])

# ==============
# Exercise
# Test-drive and implement a form page to add a new album.

# You should then be able to use the form in your web browser to add a new album, and see this new album in the albums list page.

def test_add_new_album(page, test_web_address, db_connection):
    #page.set_default_timeout(1000)
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/albums")
    page.click('text="Add album"')
    page.fill('input[name=title]', 'album=Test Album')


# ===============

# Challenge
# Test-drive and implement a form page to add a new artist.

# You should then be able to use the form in your web browser to add a new artist, and see this new artist in the artists list page.

def test_add_new_artist(page, test_web_address, db_connection):
    db_connection.seed("seeds/music_library.sql")
    page.goto(f"http://{test_web_address}/artists")
    page.click("text='Add artist'")
    page.fill('input[name=name]', "artist=Test Artist")
    