from lib.album_repository import AlbumRepository
from lib.album import Album

"""
When we call #all
We get all the albums back as instances
"""
def test_all(db_connection):
    db_connection.seed("seeds/music_library.sql")
    repository = AlbumRepository(db_connection)
    result = repository.all()
    assert result == [
        Album(1, 'Doolittle', 1989, 1),
        Album(2, 'Surfer Rosa', 1988, 1),
    ]

"""
When we call #find with an id
We get a single Album object reflecting that id
"""
def test_find(db_connection):
    db_connection.seed("seeds/music_library.sql")
    repository = AlbumRepository(db_connection)

    album = repository.find(1)
    assert album == Album(1, 'Doolittle', 1989, 1)
"""
When we call #create
We get a new record in the database.
"""
def test_create_record(db_connection):
    db_connection.seed("seeds/music_library.sql")
    repository = AlbumRepository(db_connection)

    repository.create(Album(None, "Waterloo", 1974, 2))

    result = repository.all()
    assert result == [
        Album(1, 'Doolittle', 1989, 1),
        Album(2, 'Surfer Rosa', 1988, 1),
        Album(3, 'Waterloo', 1974, 2)
    ]

"""
We remove a record from the database.
"""
def test_delete_record(db_connection):
    db_connection.seed("seeds/music_library.sql")
    repository = AlbumRepository(db_connection)
    repository.delete(2)

    result = repository.all()
    assert result == [
        Album(1, 'Doolittle', 1989, 1),
    ]